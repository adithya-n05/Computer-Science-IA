/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grade_prediction;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.util.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import java.io.*;

/**
 * FXML Controller class
 *
 * @author sameer
 */
public class SpreadSheetController implements Initializable {

    public static Class currentClass;
    public static Student currentStudent;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
